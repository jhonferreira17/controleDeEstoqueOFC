package com.example.controledeestoque;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RecuperarContaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar_conta);
    }
}